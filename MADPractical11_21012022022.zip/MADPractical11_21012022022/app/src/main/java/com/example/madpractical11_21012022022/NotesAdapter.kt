package com.example.madpractical11_21012022022

class NotesAdapter {

}