package com.example.madpractical11_21012022022

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper (context: Context?) : SQLiteOpenHelper(context, DATABASE_NAME,null, DATABASE_VERSION) {
    companion object{
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "notes_db"
    }
    override fun onCreate (db: SQLiteDatabase) {
        db. execSQL (NotesData. CREATE_TABLE)
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newversion: Int) {
        db.execSQL("DROP TABLE IF EXISTS " + NotesData. TABLE_NAME)
        onCreate (db)
    }
//    fun insertNote(note: Note) : Long {
//
//    }
//    private fun getvalues (note: Note):Contentvalues {
//    }
//    fun getNote (id: Long) : Note {
//
//    }
//    private fun getNote(cursor: Cursor): Note{
//
//    }
//    val allNotes:ArrayList<Note>
//        get () {
//
//        }
//    val notesCount:Int
//        get (){
//
//        }
//    fun updateNote (note: Note):Int {
//
//    }
//    fun deleteNote (note: Note) {
//
//    }

}