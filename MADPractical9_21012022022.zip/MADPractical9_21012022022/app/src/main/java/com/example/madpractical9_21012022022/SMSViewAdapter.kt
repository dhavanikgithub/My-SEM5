package com.example.madpractical9_21012022022

import android.content.Context
import android.widget.ArrayAdapter

class SMSViewAdapter(context: Context, private val array:ArrayList<SMSView>){

}